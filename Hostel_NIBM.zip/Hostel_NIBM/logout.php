<?php
//Add page to the session
session_start();

//Delete the session
session_destroy();

//Redirect to login1.php
header("Location:login.php")

?>